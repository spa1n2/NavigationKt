package com.example.navigationkt.ui

import com.example.navigationkt.ui.model.RecyclerModel

interface OnItemClickListener {
    fun onClick(recyclerModel: RecyclerModel)
}